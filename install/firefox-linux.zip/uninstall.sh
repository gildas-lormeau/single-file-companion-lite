#!/bin/sh

rm -f ~/.mozilla/native-messaging-hosts/singlefile_companion.json
rm -f ~/.singlefile/singlefile_companion_lite
rm -f ~/.singlefile/options.json
